<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the
 * installation. You don't have to use the web site, you can
 * copy this file to "wp-config.php" and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * MySQL settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://wordpress.org/support/article/editing-wp-config-php/
 *
 * @package WordPress
 */

// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define( 'DB_NAME', 'criarb46_wp001' );

/** MySQL database username */
define( 'DB_USER', 'criarb46_wp001' );

/** MySQL database password */
define( 'DB_PASSWORD', '2p51SMC[)J' );

/** MySQL hostname */
define( 'DB_HOST', 'localhost' );

/** Database Charset to use in creating database tables. */
define( 'DB_CHARSET', 'utf8mb4' );

/** The Database Collate type. Don't change this if in doubt. */
define( 'DB_COLLATE', '' );

/**#@+
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define( 'AUTH_KEY',         's65x4ewa2jomfdcyerby4usco93c9z6iy9mmhbfcmzlek1w5flolifbyknv42fzh' );
define( 'SECURE_AUTH_KEY',  'wmdyqys36fkfypaf8bni1jqlaoemdit2ww6lnyeyrexcso2f3kjrs5z0eqjxyucb' );
define( 'LOGGED_IN_KEY',    '4c96vefwhdbx8jlxlfrvsamnchnjmaqe0zn1t7i3n5kpsdwxwvgl6cssrrxt9qhl' );
define( 'NONCE_KEY',        'rnpmbimdqknxzenrpwywunczzly9xrwmjcv3szlrmb8jeuoogbczv5vifarohnnl' );
define( 'AUTH_SALT',        'hevwcsdl5j0up5amgknsh15ftmudxudxyvnf030locjcrkau7raricarksl7omfl' );
define( 'SECURE_AUTH_SALT', 'acqzj6ldroxqqslve9mnqrynaebwvp19grqnntkdjz1v902qzfwaszuvcoxyfxai' );
define( 'LOGGED_IN_SALT',   'lcu248jhs1tcrwrj0xejcfnj2lmczwtmhw0uhvzrsj6al31krhyemzlktgftvnvq' );
define( 'NONCE_SALT',       'uknpscrkkwzzoxkvkse5xuogviehgyv6rcxv9qi9xdu2eku0xfenns3vg607dfep' );

/**#@-*/

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix = 'wpvv_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the documentation.
 *
 * @link https://wordpress.org/support/article/debugging-in-wordpress/
 */
define( 'WP_DEBUG', false );

/* That's all, stop editing! Happy publishing. */

/** Absolute path to the WordPress directory. */
if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', __DIR__ . '/' );
}

/** Sets up WordPress vars and included files. */
require_once ABSPATH . 'wp-settings.php';
